export const NavLinks = {
  links: [
    { to: "/", title: "Homepage" },
    { to: "/careers", title: "Careers" },
  ],
};
